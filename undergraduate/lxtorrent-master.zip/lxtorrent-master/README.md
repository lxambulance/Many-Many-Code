# lxtorrent
school homework

毕设代码

linux下运行make即可编译，编译后文件lxclient为客户端，lxserver为服务器端。
