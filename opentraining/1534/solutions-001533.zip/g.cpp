#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <algorithm>
#include <bits/stdc++.h>
using namespace std;

#define rep(i, N) for (int i = 0; i < (N); i++)
#define all(a) (a).begin(), (a).end()
#define pb push_back

using ll = long long;
using i_i = tuple<int, int>;

struct bit {
    vector<ll> v;
    bit(int n) : v(n + 1) {}
    ll sum(int i) {
        ll res = 0;
        for (; i > 0; i -= i & -i) res += v[i];
        return res;
    }
    void add(int i, ll x) {
        for (i++; i < v.size(); i += i & -i) v[i] += x;
    }
};

int main() {
    int N; cin >> N;
    vector<vector<int>> a(100000);
    rep(i, N) {
        int x; scanf("%d", &x);
        a[x - 1].pb(i);
    }
    bit b(N);
    ll ans = 0;
    for (int x = 99999; x >= 0; x--) {
        for (int i: a[x]) {
            int l = b.sum(i);
            int r = b.sum(N) - b.sum(i);
            ans += min(l, r);
        }
        for (int i: a[x]) b.add(i, 1);
    }
    cout << ans << endl;
}

