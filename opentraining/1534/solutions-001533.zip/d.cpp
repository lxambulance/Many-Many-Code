#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <algorithm>
#include <bits/stdc++.h>
using namespace std;

#define rep(i, N) for (int i = 0; i < (N); i++)
#define all(a) (a).begin(), (a).end()
#define pb push_back

using ll = long long;
using i_i = tuple<int, int>;

vector<vector<int>> f(string s) {
    int N = s.length();
    vector<vector<int>> nxt(N + 2);
    vector<int> a(2, N + 1);
    nxt[N] = nxt[N + 1] = a;
    for (int i = N - 1; i >= 0; i--) {
        int k = s[i] - '0';
        a[k] = i + 1;
        nxt[i] = a;
    }
    return nxt;
}

int main() {
    string s, t;
    cin >> s >> t;
    int N = s.length();
    int M = t.length();
    vector<vector<int>> a = f(s), b = f(t);
    vector<vector<int>> dp(N + 2, vector<int>(M + 2, INT_MAX / 2));
    dp[0][0] = 0;
    rep(i, N + 2) rep(j, M + 2) rep(k, 2) {
        int _i = a[i][k];
        int _j = b[j][k];
        dp[_i][_j] = min(dp[_i][_j], dp[i][j] + 1);
    }
    vector<vector<bool>> pro(N + 2, vector<bool>(M + 2));
    pro[N + 1][M + 1] = true;
    for (int i = N + 1; i >= 0; i--) for (int j = M + 1; j >= 0; j--) rep(k, 2) {
        int _i = a[i][k];
        int _j = b[j][k];
        if (dp[_i][_j] == dp[i][j] + 1 && pro[_i][_j]) pro[i][j] = true;
    }
    // cout << dp[N + 1][M + 1] << endl;
    string ans;
    int i = 0, j = 0;
    while (i < N + 1 || j < M + 1) {
        rep(k, 2) {
            int _i = a[i][k];
            int _j = b[j][k];
            if (dp[_i][_j] == dp[i][j] + 1 && pro[_i][_j]) {
                i = _i;
                j = _j;
                ans.pb('0' + k);
                break;
            }
        }
    }
    cout << ans << endl;
}
