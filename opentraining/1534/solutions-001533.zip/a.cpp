#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <algorithm>
#include <bits/stdc++.h>
using namespace std;

#define rep(i, N) for (int i = 0; i < (N); i++)
#define all(a) (a).begin(), (a).end()
#define pb push_back

using ll = long long;
using i_i = tuple<int, int>;

bool digit(char c) {
    return '0' <= c && c <= '9';
}

vector<int> f(string s) {
    int N = s.length();
    vector<int> v;
    v.pb(0);
    for (int i = 1; i <= N - 1; i++)
        if (!digit(s[i - 1]) || !digit(s[i]))
            v.pb(i);
    v.pb(N);
    vector<int> ans;
    rep(k, v.size() - 1) {
        int l = v[k];
        int r = v[k + 1];
        if (digit(s[l])) ans.pb(stoi(s.substr(l, r - l)));
        else ans.pb(1e9 + s[l]);
    }
    return ans;
}

int main() {
    int Q; cin >> Q;
    string s; cin >> s;
    vector<int> a = f(s);
    while (Q--) {
        string t; cin >> t;
        vector<int> b = f(t);
        cout << (b < a ? '-' : '+') << endl;
    }
}
