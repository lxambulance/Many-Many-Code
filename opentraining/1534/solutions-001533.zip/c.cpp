#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <algorithm>
#include <bits/stdc++.h>
using namespace std;

#define rep(i, N) for (int i = 0; i < (N); i++)
#define all(a) (a).begin(), (a).end()
#define pb push_back

using ll = long long;
using i_i = tuple<int, int>;

int main() {
    int N, M, K;
    cin >> N >> M >> K;
    vector<int> a(1000000);
    while (K--) {
        int i, j;
        scanf("%d%d", &i, &j);
        i--; j--;
        if (j >= M) j++;
        a[N - i + abs(j - M)]++;
    }
    int ans = 0;
    rep(d, 1000000) {
        if (a[d]) {
            ans = d;
            a[d + 1] += a[d] - 1;
        }
    }
    cout << ans << endl;
}

