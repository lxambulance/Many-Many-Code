#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <algorithm>
#include <bits/stdc++.h>
using namespace std;
//#pragma GCC optimize("Ofast")
//#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,tune=native")

#define ms(s, n) memset(s, n, sizeof(s))
#define FOR(i, a, b) for (int i = (a); i < (b); ++i)
#define FORd(i, a, b) for (int i = (a) - 1; i >= (b); --i)
#define FORall(it, a) for (__typeof((a).begin()) it = (a).begin(); it != (a).end(); it++)
#define sz(a) int((a).size())
#define present(t, x) (t.find(x) != t.end())
#define all(a) (a).begin(), (a).end()
#define uni(a) (a).erase(unique(all(a)), (a).end())
#define pb push_back
#define pf push_front
#define mp make_pair
#define fi first
#define se second
#define prec(n) fixed<<setprecision(n)
#define bit(n, i) (((n) >> (i)) & 1)
#define bitcount(n) __builtin_popcountll(n)
typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;
typedef pair<int, int> pi;
typedef vector<int> vi;
typedef vector<pi> vii;
const int MOD = (int) 1e9 + 7;
const int FFTMOD = 119 << 23 | 1;
const int INF = (int) 1e9 + 23111992;
const ll LINF = (ll) 1e18 + 23111992;
const ld PI = acos((ld) -1);
const ld EPS = 1e-9;
inline ll gcd(ll a, ll b) {ll r; while (b) {r = a % b; a = b; b = r;} return a;}
inline ll lcm(ll a, ll b) {return a / gcd(a, b) * b;}
inline ll fpow(ll n, ll k, int p = MOD) {ll r = 1; for (; k; k >>= 1) {if (k & 1) r = r * n % p; n = n * n % p;} return r;}
template<class T> inline int chkmin(T& a, const T& val) {return val < a ? a = val, 1 : 0;}
template<class T> inline int chkmax(T& a, const T& val) {return a < val ? a = val, 1 : 0;}
inline ull isqrt(ull k) {ull r = sqrt(k) + 1; while (r * r > k) r--; return r;}
inline ll icbrt(ll k) {ll r = cbrt(k) + 1; while (r * r * r > k) r--; return r;}
inline void addmod(int& a, int val, int p = MOD) {if ((a = (a + val)) >= p) a -= p;}
inline void submod(int& a, int val, int p = MOD) {if ((a = (a - val)) < 0) a += p;}
inline int mult(int a, int b, int p = MOD) {return (ll) a * b % p;}
inline int inv(int a, int p = MOD) {return fpow(a, p - 2, p);}
inline int sign(ld x) {return x < -EPS ? -1 : x > +EPS;}
inline int sign(ld x, ld y) {return sign(x - y);}
mt19937 mt(chrono::high_resolution_clock::now().time_since_epoch().count());
inline int myrand() {return abs((int) mt());}
#define db(x) cerr << #x << " = " << (x) << " ";
#define endln cerr << "\n";

#define double long double
struct point_t {
    double x, y;
    point_t(double x = 0, double y = 0) : x(x), y(y) {}
    point_t operator - (const point_t& rhs) {
        return point_t(x - rhs.x, y - rhs.y);
    }
    point_t operator + (const point_t& rhs) {
        return point_t(x + rhs.x, y + rhs.y);
    }
    point_t operator * (const double& k) {
        return point_t(x * k, y * k);
    }
    point_t operator / (const double& k) {
        return point_t(x / k, y / k);
    }
};

inline double sqr(double x) {return x * x;}
inline double dist(point_t a, point_t b) {
    return sqrt(sqr(a.x - b.x) + sqr(a.y - b.y));
}
inline double cross(point_t a, point_t b) {
    return a.x * b.y - a.y * b.x;
}
point_t lineinsect(point_t a, point_t b, point_t c, point_t d) {
    b = b - a; d = c - d; c = c - a;
    return a + b * cross(c, d) / cross(b, d);
}

const int maxn = 5000 + 5;
int n;
point_t p[maxn];

double calc(point_t a, point_t b, point_t c, point_t d) {
    point_t q = lineinsect(a, a + c - b, c, d);
    return dist(b, q);
}

double find(point_t a, point_t b, point_t c, point_t d, int sign) {
    double lo = 0, hi = 1;
    FOR(it, 0, 100) {
        double m1 = (lo + lo + hi) / 3;
        double m2 = (lo + hi + hi) / 3;
        if (calc(a, (b - a) * m1 + a, c, d) * sign > calc(a, (b - a) * m2 + a, c, d) * sign) {
            lo = m1;
        }
        else {
            hi = m2;
        }
    }
    double m = 0.5 * (lo + hi);
    return calc(a, (b - a) * m + a, c, d);
}

void chemthan() {
    cin >> n;
    FOR(i, 0, n) {
        int x, y; cin >> x >> y;
        p[i] = point_t(x, y);
    }
    double area = 0.0;
    FOR(i, 0, n) {
        area += cross(p[i], p[(i + 1) % n]);
    }
    double mn = +INF, mx = -INF;
    FOR(i, 0, n) {
        double sum = 0.0;
        int ni = i;
        FOR(j, 1, n + 1) {
            int u = (i + j - 1) % n;
            int v = (i + j) % n;
            sum += cross(p[u], p[v]);
            if (2 * (sum + cross(p[v], p[i])) > area) {
                ni = u;
                sum -= cross(p[u], p[v]);
                break;
            }
        }
        sum += cross(p[ni], p[i]);
        double need = area / 2 - sum;
        int nni = (ni + 1) % n;
        int j = (i + 1) % n;
        double x = cross(p[ni] - p[i], p[nni] - p[i]);
        assert(sign(need, x) < 0);
        point_t q = (p[nni] - p[ni]) * need / x + p[ni];
        double lo = 0, hi = 1;
        FOR(it, 0, 100) {
            double mi = 0.5 * (lo + hi);
            if (cross(q - ((p[j] - p[i]) * mi + p[i]), p[nni] - p[i]) >= 0) {
                lo = mi;
            }
            else {
                hi = mi;
            }
        }
        double mi = 0.5 * (lo + hi);
        chkmin(mn, find(p[i], (p[j] - p[i]) * mi + p[i], q, p[nni], +1));
        chkmax(mx, find(p[i], (p[j] - p[i]) * mi + p[i], q, p[nni], -1));
    }
    cout << prec(12) << mn << "\n" << mx << "\n";
}

int main(int argc, char* argv[]) {
    ios_base::sync_with_stdio(0), cin.tie(0);
    if (argc > 1) {
        assert(freopen(argv[1], "r", stdin));
    }
    if (argc > 2) {
        assert(freopen(argv[2], "wb", stdout));
    }
    chemthan();
    //cerr << "\nTime elapsed: " << 1000 * clock() / CLOCKS_PER_SEC << "ms\n";
    return 0;
}
