#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <algorithm>
#include <bits/stdc++.h>
using namespace std;

#define rep(i, N) for (int i = 0; i < (N); i++)
#define all(a) (a).begin(), (a).end()
#define pb push_back

using ll = long long;
using i_i = tuple<int, int>;

struct dice {
    mt19937 mt;
    dice() {
        random_device rd;
        mt = mt19937(rd());
    }
    int operator()(int x) { return this->operator()(0, x - 1); }
    int operator()(int x, int y) {
        uniform_int_distribution<int> dist(x, y);
        return dist(mt);
    }
} dc;

struct union_find {
    vector<int> v;
    union_find(int n) : v(n, -1) {}
    int find(int x) { return v[x] < 0 ? x : v[x] = find(v[x]); }
    void unite(int x, int y) {
        x = find(x); y = find(y);
        if (x == y) return;
        if (-v[x] < -v[y]) swap(x, y);
        v[x] += v[y]; v[y] = x;
    }
    bool root(int x) { return v[x] < 0; }
    bool same(int x, int y) { return find(x) == find(y); }
    int size(int x) { return -v[find(x)]; }
};

void dfs_c(int u, vector<vector<int>>& a, vector<int>& c) {
    int N = a.size();
    rep(v, N) if (!a[u][v] && c[v] == -1) {
        c[v] = c[u];
        dfs_c(v, a, c);
    }
}

bool dfs(int u, vector<vector<int>>& a, vector<bool>& vis, vector<bool>& unko, vector<vector<int>>& b) {
    int N = a.size();
    if (vis[u]) return false;
    vis[u] = true;
    if (unko[u]) {
        unko[u] = false;
        return true;
    }
    rep(v, N) if (!a[u][v] && dfs(v, a, vis, unko, b)) {
        b[u][v] ^= 1;
        b[v][u] ^= 1;
        return true;
    }
    return false;
}

int main() {
    int N, M;
    cin >> N >> M;
    vector<vector<int>> a(N, vector<int>(N));
    while (M--) {
        int u, v; cin >> u >> v;
        a[u - 1][v - 1] = a[v - 1][u - 1] = true;
    }
    rep(t, 100) {
        vector<vector<int>> _a = a;
        union_find uf(N);
        rep(u, N) rep(v, N) if (a[u][v]) uf.unite(u, v);
        while (uf.size(0) < N) {
            int u = dc(N), v = dc(N);
            if (!uf.same(u, v)) {
                _a[u][v] = _a[v][u] = true;
                uf.unite(u, v);
            }
        }
        int K = 0;
        vector<int> c(N, -1);
        rep(u, N) if (c[u] == -1) {
            c[u] = K++;
            dfs_c(u, _a, c);
        }
        vector<int> deg(N);
        rep(u, N) rep(v, N) if (_a[u][v]) deg[u]++;
        vector<int> odd(K);
        rep(u, N) if (deg[u] % 2) odd[c[u]]++;
        bool ok = true;
        rep(k, K) if (odd[k] % 2) ok = false;
        if (!ok) continue;
        vector<bool> unko(N);
        rep(u, N) if (deg[u] % 2) unko[u] = true;
        vector<vector<int>> b(N, vector<int>(N));
        rep(u, N) if (unko[u]) {
            unko[u] = false;
            vector<bool> vis(N);
            dfs(u, _a, vis, unko, b);
        }
        vector<i_i> E;
        rep(u, N) for (int v = u + 1; v < N; v++) {
            if (!a[u][v] && _a[u][v]) E.pb(i_i{u, v});
            if (b[u][v]) E.pb(i_i{u, v});
        }
        cout << E.size() << endl;
        for (i_i e: E) {
            int u, v;
            tie(u, v) = e;
            cout << u + 1 << ' ' << v + 1 << endl;
        }
        return 0;
    }
    cout << -1 << endl;
}
