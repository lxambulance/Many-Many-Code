#include <bits/stdc++.h>
using namespace std;

#define rep(i, N) for (int i = 0; i < (N); i++)
#define all(a) (a).begin(), (a).end()
#define pb push_back

using ll = long long;
using i_i = tuple<int, int>;
using vi = vector<int>;

struct hl_decomp {
    int N, M;
    vector<vi> G;
    vi sz, id, par, dep;
    hl_decomp(int _N, vector<vi> _G) : N(_N), G(_G), sz(N), id(N), par(N), dep(N) {
        dfs_sz(0, -1);
        dfs_decomp(0, -1);
        M = 1; par[0] = -1; dfs_decomp(0, -1);
        dfs_dep(0, -1);
    }
    void dfs_sz(int u, int p) {
        sz[u] = 1;
        for (int v: G[u]) if (v != p) {
            dfs_sz(v, u);
            sz[u] += sz[v];
        }
    }
    void dfs_decomp(int u, int p) {
        int v0 = -1;
        for (int v: G[u]) if (v != p)
            if (v0 == -1 || sz[v] > sz[v0])
                v0 = v;
        for (int v: G[u]) if (v != p) {
            if (v == v0) {
                id[v] = id[u];
                par[v] = par[u];
            }
            else {
                id[v] = M++;
                par[v] = u;
            }
            dfs_decomp(v, u);
        }
    }
    void dfs_dep(int u, int p) {
        for (int v: G[u]) if (v != p) {
            dep[v] = dep[u] + 1;
            dfs_dep(v, u);
        }
    }
    int lca(int u, int v) {
        while (id[u] != id[v]) {
            int _u = par[u], _v = par[v];
            int du = (_u == -1 ? -1 : dep[_u]);
            int dv = (_v == -1 ? -1 : dep[_v]);
            if (du >= dv) u = _u;
            else v = _v;
        }
        return dep[u] < dep[v] ? u : v;
    }
    int dist(int u, int v) {
        int w = lca(u, v);
        // cerr << u << ' ' << v << ' ' << dep[u] + dep[v] - dep[w] * 2 << endl;
        return dep[u] + dep[v] - dep[w] * 2;
    }
};

void dfs_el(int u, int p, vector<vector<int>>& G, int& k, vector<int>& e) {
    e[u] = k++;
    for (int v: G[u]) if (v != p) dfs_el(v, u, G, k, e);
}

const int C = 100000;

void insert(int c, int u, vector<set<int>>& st, vector<int>& unko, hl_decomp& hl, vector<int>& e, vector<int>& ei) {
    set<int>& s = st[c];
    auto it = s.insert(e[u]).first;
    int l, r;
    if (it == s.begin()) l = *prev(s.end());
    else l = *prev(it);
    if (next(it) == s.end()) r = *s.begin();
    else r = *next(it);
    unko[c] += hl.dist(u, ei[l]);
    unko[c] += hl.dist(u, ei[r]);
    unko[c] -= hl.dist(ei[l], ei[r]);
}

void erase(int c, int u, vector<set<int>>& st, vector<int>& unko, hl_decomp& hl, vector<int>& e, vector<int>& ei) {
    set<int>& s = st[c];
    auto it = s.lower_bound(e[u]);
    int l, r;
    if (it == s.begin()) l = *prev(s.end());
    else l = *prev(it);
    if (next(it) == s.end()) r = *s.begin();
    else r = *next(it);
    unko[c] -= hl.dist(u, ei[l]);
    unko[c] -= hl.dist(u, ei[r]);
    unko[c] += hl.dist(ei[l], ei[r]);
    s.erase(e[u]);
}

int main() {
    int N; cin >> N;
    vector<vector<int>> G(N);
    rep(i, N - 1) {
        int u, v;
        scanf("%d%d", &u, &v);
        u--; v--;
        G[u].pb(v);
        G[v].pb(u);
    }
    hl_decomp hl(N, G);
    vector<int> e(N), ei(N);
    int k = 0;
    dfs_el(0, -1, G, k, e);
    rep(u, N) ei[e[u]] = u;
    vector<int> col(N);
    rep(u, N) {
        scanf("%d", &col[u]);
        col[u]--;
    }
    vector<set<int>> st(C);
    vector<int> unko(C);
    rep(u, N) insert(col[u], u, st, unko, hl, e, ei);
    int Q; cin >> Q;
    while (Q--) {
        char t;
        scanf("%*c%c", &t);
        if (t == 'U') {
            int u, c;
            scanf("%d%d", &u, &c);
            u--; c--;
            erase(col[u], u, st, unko, hl, e, ei);
            col[u] = c;
            insert(col[u], u, st, unko, hl, e, ei);
        }
        if (t == 'Q') {
            int c;
            scanf("%d", &c);
            c--;
            if (st[c].empty()) printf("%d\n", -1);
            else printf("%d\n", unko[c] / 2);
        }
    }
}
