#include <bits/stdc++.h>
using namespace std;
#define PB push_back
#define ZERO (1e-10)
#define INF int(1e9+1)
#define CL(A,I) (memset(A,I,sizeof(A)))
#define DEB printf("DEB!\n");
#define D(X) cout<<"  "<<#X": "<<X<<endl;
#define EQ(A,B) (A+ZERO>B&&A-ZERO<B)
typedef long long ll;
typedef pair<ll,ll> pll;
typedef vector<int> vi;
typedef pair<int,int> ii;
typedef vector<ii> vii;
#define IN(n) int n;scanf("%d",&n);
#define FOR(i, m, n) for (int i(m); i < n; i++)
#define F(n) FOR(i,0,n)
#define FF(n) FOR(j,0,n)
#define FT(m, n) FOR(k, m, n)
#define aa first
#define bb second
void ga(int N,int *A){F(N)scanf("%d",A+i);}
#define MX (100005)
#define MQ (MX)
#define SQ (333)
#define SZ (MQ/SQ+1)
struct CON{
    struct DSU{
        vector<pair<ii,ii>> G;
        int C[MX],M[MX],B[SQ*4],W,c[SQ*4],T[SQ*4],Z[MX];
        int gc(int a){return C[a]=(a==C[a]?a:gc(C[a]));}
        bool con(int a,int b){
            if(gc(a)==gc(b))return 0;
            return C[C[b]]=C[a],1;
        }
        void CLR(int N){iota(C,C+N,W=0),G.clear(),CL(M,-1),CL(Z,-1);}
        int pn(int x){if(!~M[x])B[W]=x,M[x]=W++;return M[x];}
        void ADD(int x,int y,ii t){x=pn(x),y=pn(y),G.PB({{x,y},t});}
        int GC(int a){return c[a]=(a==c[a]?a:GC(c[a]));}
        bool CON(int a,int b){
            if(GC(a)==GC(b))return 0;
            return c[c[b]]=c[a],1;
        }
        bool is(int x,int y,int t){
            x=pn(x),y=pn(y);
            F(W)T[i]=c[i]=gc(B[i]);
            F(W)if(!~Z[c[i]])Z[c[i]]=i;
            F(W)c[i]=Z[c[i]];
            F(W)Z[T[i]]=-1;
            for(auto&h:G)if(h.bb.aa<t&&h.bb.bb>t)CON(h.aa.aa,h.aa.bb);
            return GC(x)==GC(y);
        }
    }D[SZ];
    map<ii,int> l;
    int A[MQ],X[MQ],Y[MQ],I,E[MQ];
    void CLR(int N){F(SZ)D[i].CLR(N);l.clear(),I=0;}
    void ADD(int x,int y){if(x>y)swap(x,y);A[I]=1,E[I]=INF,X[I]=x,Y[I]=y,l[{x,y}]=I++;}
    void DEL(int x,int y){if(x>y)swap(x,y);A[I]=-1,E[l[{x,y}]]=I++;}
    void QY(int x,int y){A[I]=0,X[I]=x,Y[I++]=y;}
    void GO(vi&o){
        F(I/SQ+1){
            FF(SQ*i+SQ&&j<I)if(A[j]>0){
                if(E[j]>=SQ*(i+1)&&j<SQ*i)D[i].con(X[j],Y[j]);
                else if(E[j]>=SQ*i)D[i].ADD(X[j],Y[j],{j,E[j]});
            }
        }
        F(I)if(!A[i])o.PB(D[i/SQ].is(X[i],Y[i],i));
    }
}T;

int N,Q,A[MX],X[MX],Y[MX],V[MX],O[MX];
set<ii> F;
vi o;
int main(void){
    scanf("%d%d",&N,&Q),CL(O,-1);
    F(Q){
        scanf("%d%d%d",A+i,X+i,Y+i);
        if(!A[i])scanf("%d",V+i);
    }
    FF(10){
        T.CLR(N),F.clear();
        F(Q)if(!A[i]){
                if(V[i]<=j)T.ADD(X[i],Y[i]),F.insert(minmax(X[i],Y[i]));
            }else if(A[i]^1)T.QY(X[i],Y[i]);
            else if(F.count(minmax(X[i],Y[i])))T.DEL(X[i],Y[i]),F.erase(minmax(X[i],Y[i]));
        o.clear(),T.GO(o);
        F((int)o.size())if(!~O[i]&&o[i])O[i]=j;
    }
    F((int)o.size())printf("%d\n",O[i]);
    return 0;
}
